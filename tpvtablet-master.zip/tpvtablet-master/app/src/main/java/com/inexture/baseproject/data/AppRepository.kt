package com.inexture.baseproject.data

import androidx.lifecycle.LiveData
import com.inexture.baseproject.App
import com.inexture.baseproject.model.Repo
import com.inexture.baseproject.network.ApiClient
import com.inexture.baseproject.network.resources.*
import kotlinx.coroutines.CoroutineScope

object AppRepository {


}