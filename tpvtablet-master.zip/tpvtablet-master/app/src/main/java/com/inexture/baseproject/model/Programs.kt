package com.inexture.baseproject.model

import com.google.gson.annotations.SerializedName

data class Programs(
        @SerializedName("id")
        var id: String?,
        @SerializedName("ProgramCode")
        var programCode: String?,
        @SerializedName("ProgramName")
        var programName: String?,
        @SerializedName("Saleschannel")
        var saleschannel: String?,
        @SerializedName("monthlysf")
        var monthlysf: String?,
        @SerializedName("earlyterminationfee")
        var earlyterminationfee: String?,
        @SerializedName("Rate")
        var rate: String?,
        @SerializedName("Term")
        var term: String?,
        @SerializedName("State")
        var state: String?,
        @SerializedName("UnitOfMeasureName")
        var unitOfMeasureName: String?,
        @SerializedName("PremiseTypeName")
        var premiseTypeName: String?,
        @SerializedName("AccountNumberTypeName")
        var accountNumberTypeName: String?,
        @SerializedName("AccountNumberLength")
        var accountNumberLength: String?

)