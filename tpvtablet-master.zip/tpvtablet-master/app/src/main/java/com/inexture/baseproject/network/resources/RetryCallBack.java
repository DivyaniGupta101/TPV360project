package com.inexture.baseproject.network.resources;

public interface RetryCallBack {
    public void retry();
}