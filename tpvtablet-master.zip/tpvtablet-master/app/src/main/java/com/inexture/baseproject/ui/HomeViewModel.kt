package com.inexture.baseproject.ui

import com.inexture.baseproject.network.resources.CoroutineScopedViewModel

class HomeViewModel : CoroutineScopedViewModel() {


}